# Example 5.8 applied to the U.S. Industrial Production Index

library(KFAS)

# read and transform data
data <- read.csv("GDP_IP_US.csv")$INDPRO
y <- ts(100*log(data), start = c(1947, 1), frequency = 12)
plot(y)

# create non-fitted model
mod1 <- SSModel(y~SSMtrend(2, list(0, NA)) + SSMcycle(60, NA, P1inf = matrix(0, 2, 2)), H = NA)

# Put the unknown parameters in the right place in the system matrices:
# prameters i pars are as in
# c(log(var_zeta, log(var_psi), logit(rho), log(period), log(var_eps)))
update1 <- function(pars, model, ...) {
  # compute and assign parameters to variables
  var_zeta  <- exp(pars[1])
  var_psi   <- exp(pars[2])
  rho       <- 1/(1+exp(-pars[3]))
  period    <- exp(pars[4])
  freq      <- 2*pi/period
  co <- rho*cos(freq)
  si <- rho*sin(freq)
  var_eps <- exp(pars[5])
  
  # assign parameters to system matrices
  model$T[3, 3, 1] <- model$T[4, 4, 1] <- co
  model$T[4, 3, 1] <- -si
  model$T[3, 4, 1] <- si
  model$Q[2, 2, 1] <- var_zeta
  model$Q[3, 3, 1] <- model$Q[4, 4, 1] <- var_psi*(1 - rho^2)
  model$H[1, 1, 1] <- var_eps
  model$P1[3, 3] <- model$P1[4, 4] <- var_psi
  model
}
  
fit1 <- fitSSM(mod1, c(log(0.00001), log(10), 3, log(60), log(30)), update1)

# check convergence of ML estimates
if (fit1$optim.out$convergence) print(fit1$optim.out$message)

# state smoother
smo1 <- KFS(fit1$model, smoothing = "state")

# plot log-series and level
plot(y)
lines(smo1$alphahat[, "level"], col = "red")

# plot business cycle (output gap)
plot(smo1$alphahat[, "cycle"])

# cycle period
cat("Cycle Period =", exp(fit1$optim.out$par[4]), "months\n")
