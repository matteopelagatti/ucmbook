library(KFAS)

y <- log(AirPassengers)*100 # take the log of the airline time series

model <- SSModel(y~SSMtrend(degree = 2, Q = list(NA,NA))+
                   SSMseasonal(period = 12, sea.type = "dummy", Q = NA),
                 H = NA)

fit <- fitSSM(model = model, inits=c(0,0,0,0))

fit$optim.out$convergence

round((exp(fit$optim.out$par)),4)

smo <- KFS(fit$model, smoothing = "state") # run the smoother

plot(y, main="100*log(AirPassengers) with level component")
lines(smo$alphahat[,1], lwd=2)
lines(smo$alphahat[,1]+2*sqrt(smo$V[1,1,]), lty=2) # upper confidence limit
lines(smo$alphahat[,1]-2*sqrt(smo$V[1,1,]), lty=2) # lower confidence limit

plot(smo$alphahat[,3], ylab="Seasonal component", main="Seasonal component")
lines(smo$alphahat[,3]+2*sqrt(smo$V[3,3,]), lty=2) # upper confidence limit
lines(smo$alphahat[,3]-2*sqrt(smo$V[3,3,]), lty=2) # lower confidence limit

plot(AirPassengers, ylab="Seasonal factor", main="AirPassengers with level component")
lines(exp(smo$alphahat[,1]/100), lwd=2)
lines(exp(smo$alphahat[,1]/100+2*sqrt(smo$V[1,1,])/100), lty=2) # upper confidence limit
lines(exp(smo$alphahat[,1]/100-2*sqrt(smo$V[1,1,])/100), lty=2) # lower confidence limit

plot(exp(smo$alphahat[,3]/100), main="Seasonal factor")
lines(exp(smo$alphahat[,3]/100+2*sqrt(smo$V[3,3,])/100), lty=2) # upper confidence limit
lines(exp(smo$alphahat[,3]/100-2*sqrt(smo$V[3,3,])/100), lty=2) # lower confidence limit
