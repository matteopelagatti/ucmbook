library(KFAS)

# load data
data <- read.csv("USmacro07.csv")

# make time series with 100*log of investments
y <- ts(log(data$PRIVATE_INV), start = c(1947, 1), frequency = 4)*100
plot(y)

# make SSModel object
mod1 <- SSModel(y~SSMtrend(2, list(0, NA))+SSMcycle(20, NA), H = NA)

# update function: sets parameters into the right elements of system matrices
# assume parameters are in this order/transformation
# c(log(var_zeta), log(var_psi), log(var_epsilon), log(period), logit(rho))
updatefn <- function(par, model, ...) {
  # cycle's parameters
  lambda <- 2*pi/exp(par[4])  # cycle: frequency
  rho <- 1/(1 + exp(-par[5])) # cycle: damping factor
  var_kappa <- exp(par[2])*(1 - rho^2) # cycle: variance of kappa's
  co <- rho*cos(lambda) # cycle: rho*cos(lambda)
  si <- rho*sin(lambda) # cycle: rho*sin(lambda)
  # place parameters into system matrices
  model$Q[2, 2, 1] <- exp(par[1])
  model$Q[3, 3, 1] <- model$Q[4, 4, 1] <- var_kappa
  model$H[1, 1, 1] <- exp(par[3])
  model$T[3, 3, 1] <- model$T[4, 4, 1] <- co
  model$T[4, 3, 1] <- -si
  model$T[3, 4, 1] <- si
  model
}

# estimate unknown parameters by max-lik
fit1 <- fitSSM(mod1, c(log(.1), log(10), log(100), log(16), 2), updatefn)
if (!fit1$optim.out$convergence) cat("No convergence\n") else cat("Full convergence\n")
par1 <- c(exp(fit1$optim.out$par[1:4]), 1/(1+exp(-fit1$optim.out$par[5])))
names(par1) <- c("var_zeta", "var_psi", "var_epsilon", "period", "rho")
round(par1, 3)

# state smoothing
ssmo1 <- KFS(fit1$model, smoothing = "state")

# plot series with trend
plot(y)
lines(ssmo1$alphahat[,"level"], col = "red")

# plot business cycle
plot(ssmo1$alphahat[,"cycle"])


# let's make an order-2 cycle
SSMhcycle <- function(order = 1, period, rho, Q) {
  lambda <- 2*pi/period
  co <- rho*cos(lambda)
  si <- rho*sin(lambda)
  mT <- matrix(0, 2*order, 2*order)
  for (i in seq_len(order)) {
    from <- (i - 1)*2 + 1
    mT[from, from] <- mT[from + 1, from + 1] <- co
    mT[from + 1, from] <- -si
    mT[from, from + 1] <- si
    if (i < order) {
      mT[from, from + 2] <- mT[from + 1, from + 3] <- 1
    }
  }
  mQ <- matrix(0, 2, 2)
  mQ[1, 1] <- mQ[2, 2] <- Q
  mR <- matrix(0, 2*order, 2)
  mR[2*order - 1, 1] <- mR[2*order, 2] <- 1
  va1 <- rep(0, 2*order)
  mP1 <- matrix( solve(diag(4*order^2) - mT %x% mT) %*% matrix(mR %*% mQ %*% t(mR), 4*order^2, 1), 2*order, 2*order)
  mZ <- matrix(0, 1, 2*order)
  mZ[1, 1] <- 1
  list(Z = mZ, T = mT, R = mR, Q = mQ, a1 = va1, P1 = mP1)
}

cyc <- SSMhcycle(order = 2, period = 20, rho = 0.9, Q = NA)

mod2 <- SSModel(y~SSMtrend(2, list(0, NA))+SSMcustom(cyc$Z, cyc$T, cyc$R, cyc$Q, cyc$a1, cyc$P1), H = NA)

# update function: sets parameters into the right elements of system matrices
# assume parameters are in this order/transformation
# c(log(var_zeta), log(var_kappa), log(var_epsilon), invtrans(period), logit(rho))
updatefn2 <- function(par, model, ...) {
  # cycle's parameters
  period <- 8 + 32/(1 + exp(par[4]))
  lambda <- 2*pi/period  # cycle: frequency
  rho <- 1/(1 + exp(-par[5])) # cycle: damping factor
  co <- rho*cos(lambda) # cycle: rho*cos(lambda)
  si <- rho*sin(lambda) # cycle: rho*sin(lambda)
  # place parameters into system matrices
  model$Q[2, 2, 1] <- exp(par[1])
  model$Q[3, 3, 1] <- model$Q[4, 4, 1] <- exp(par[2])
  model$H[1, 1, 1] <- exp(par[3])
  model$T[3, 3, 1] <- model$T[4, 4, 1] <- co
  model$T[4, 3, 1] <- -si
  model$T[3, 4, 1] <- si
  model$T[5, 5, 1] <- model$T[6, 6, 1] <- co
  model$T[6, 5, 1] <- -si
  model$T[5, 6, 1] <- si
  model$P1[3:6, 3:6] <- matrix(solve(diag(16) - model$T[3:6, 3:6, 1] %x% model$T[3:6, 3:6, 1]) %*%
                               matrix(model$R[3:6,3:4,1] %*% model$Q[3:4, 3:4, 1]%*% t(model$R[3:6,3:4,1]),
                                       16, 1), 4,  4
                              )
  model
}

fit2 <- fitSSM(mod2, c(log(.1), log(10), log(100), 0, 2), updatefn2)
if (!fit1$optim.out$convergence) cat("No convergence\n") else cat("Full convergence\n")
par2 <- c(exp(fit2$optim.out$par[1:3]), 8 + 32/(1+exp(-fit2$optim.out$par[5])), 1/(1+exp(-fit2$optim.out$par[5])))
names(par2) <- c("var_zeta", "var_psi", "var_epsilon", "period", "rho")
round(par2, 2)

ssmo2 <- KFS(fit2$model, smoothing = "state")

# plot series with trend
plot(y)
lines(ssmo2$alphahat[,"level"], col = "red")

# plot business cycle
plot(ssmo2$alphahat[, 3])

# compare cycles
plot(ssmo1$alphahat[, 3], col = "blue")
lines(ssmo2$alphahat[, 3], col = "red")

# alternative way to make the order-2 cycle
mod3 <- SSModel(y~SSMtrend(2, list(0, NA))+SSMcycle(20, 0)+SSMcycle(20, NA), H = NA)
mod3$T[3:4, 5:6, 1] <- diag(2)
mod3$Z[1, 5, 1] <- 0
mod3$Q <- array(0, c(3, 3, 1))
mod3$R <- array(0, c(6, 3, 1))
mod3$R[2, 1, 1] <- 1
mod3$R[5, 2, 1] <- 1
mod3$R[6, 3, 1] <- 1
mod3$P1inf[3:6, 3:6] <- 0
attr(mod3, "k") <- 3L

# c(log(var_zeta), log(var_kappa), log(var_epsilon), invtrans(period), logit(rho))
updatefn3 <- function(par, model, ...) {
  # cycle's parameters
  period <- 8 + 32/(1 + exp(par[4])) # cycle: force period between 2 and 8 yrs
  lambda <- 2*pi/period  # cycle: frequency
  rho <- 1/(1 + exp(-par[5])) # cycle: damping factor
  co <- rho*cos(lambda) # cycle: rho*cos(lambda)
  si <- rho*sin(lambda) # cycle: rho*sin(lambda)
  mR <- matrix(c(co, -si, si, co), 2, 2)
  # place parameters into system matrices
  model$T[3:4, 3:4, 1] <- mR
  model$T[5:6, 5:6, 1] <- mR
  model$Q[1, 1, 1] <- exp(par[1])
  model$Q[2, 2, 1] <- exp(par[2])
  model$Q[3, 3, 1] <- exp(par[2])
  model$H[1, 1, 1] <- exp(par[3])
  mQsub <- model$R[3:6, 2:3, 1] %*% model$Q[2:3, 2:3, 1] %*% t(model$R[3:6, 2:3, 1])
  model$P1[3:6, 3:6] <- matrix(
    solve( diag(16) - model$T[3:6, 3:6, 1] %x% model$T[3:6, 3:6, 1]) %*% as.numeric(mQsub),
    4, 4
  )
  model
}

fit3 <- fitSSM(mod3, c(log(.1), log(10), log(100), 0, 2), updatefn3)
if (!fit1$optim.out$convergence) cat("No convergence\n") else cat("Full convergence\n")
par3 <- c(exp(fit3$optim.out$par[1:3]), 8 + 32/(1+exp(-fit2$optim.out$par[5])), 1/(1+exp(-fit2$optim.out$par[5])))
names(par2) <- c("var_zeta", "var_psi", "var_epsilon", "period", "rho")
round(par2, 2)

ssmo2 <- KFS(fit2$model, smoothing = "state")

# plot series with trend
plot(y)
lines(ssmo2$alphahat[,"level"], col = "red")

# plot business cycle
plot(ssmo2$alphahat[, 3])
