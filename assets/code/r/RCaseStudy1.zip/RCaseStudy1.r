# Case Study 1, Section 9.1 of
# Pelagatti (2015) Time Series Modelling with Unobserved Components. Chapman & Hall/CRC Press

# The aim is measuring the persistent and the transient effect in road injuries of the introduction of
# the point system in the Italian traffic legislation.

library(KFAS)
data <- read.csv("injured.csv") # read data

# convert data into ts object
inj <- ts((data$x), c(2001,1), freq=12) 
plot(inj)
n <- length(inj) #  n = number of observations

# dummy variables that takes 1 starting with July 2003 (introduction of point system)
stp <- inj
stp[] <- 0
window(stp, c(2003,7), c(2013,12)) <- 1

# function to diagonally concatenate two matrices
dcat <- function(X,Y)
{
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  d1 <- dim(X)
  d2 <- dim(Y)
  XY <- matrix(0, d1[1], d2[2])
  YX <- matrix(0, d2[1], d1[2])
  cbind(rbind(X,YX),rbind(XY,Y))
}

# matrices for local linear trend
T1 <- matrix(c(1,0,1,1),2,2)
Q1 <- diag(c(NA,NA))

# matrices for seasonal component by stochastic dummies
T2 <- rbind(rep(-1,11),cbind(diag(10),rep(0,10)))
Q2 <- matrix(NA)

# matrix for intervention
T3 <- matrix(1)

# concatenate T matrices to get system with LLT + SEAS + STEP DUMMY
T <- dcat(T1,T2)
T <- dcat(T,T3)

# concatenate Q matrices to get system with LLT + SEAS + STEP DUMMY
Q <- dcat(Q1,Q2)

# KFAS uses a further matrix R that assignes the (here 3) disturbances
# to the first three state variables
R <- matrix(0,14,3)
R[1,1] <- R[2,2] <- R[3,3] <- 1

# matrix Z
Z <- matrix(c(1,0,1,rep(0,11)),1,14)

# matrices for defininf the initial state
a1 <- matrix(0,14,1)
P1 <- matrix(0,14,14)
P1inf <- diag(14)

# let us change into arrays those matrices that change with time
T <- array(T,c(14,14,n)) # this matrix will be then changed by the estimation function
# the 14th element is equal to 0 untill June 2003 and then equalt to 1 from July 2003
Z <- array(Z,c(1,14,n))
Z[1,14,] <- stp

# let us estimate the model with a TEMPORARY SHIFT but without LEVEL SHIFT
model <- SSModel(inj~0+SSMcustom(Z,T,R,Q,a1,P1,P1inf,1,n), H=NA)

# the logit function maps (-inf,inf) into (0,1)
# we need it to buond the decay (delta) parameter in the transfer function model
logit <- function(x)
{
  1/(1+exp(-x))
}

# function that assigns the parameters to be estimated (pars) into the right
# matrix elements of the SS model (model)
update <- function(pars, model, ...)
{
  model$Q[1,1,1]   <- exp(pars[1]) # eta variance
  model$Q[2,2,1]   <- exp(pars[2]) # zeta variance
  model$Q[3,3,1]   <- exp(pars[3]) # omega variance
  model$H[1,1,1]   <- exp(pars[4]) # epsilon variance
  model$T[14,14,32:156] <- logit(pars[5]) # delta coefficient of transfer function
  model
}

# estimate
fit <- fitSSM(model, c(5,5,5,5,1), update3)

# state smoothing
staSmo <- KFS(fit$model, smoothing="state")

plot(staSmo$alphahat[,14]*Z[1,14,], ylab="Impact of the score system (n. of injuries)",
     main="Model only with transitory effect")

plot(inj, ylab="Number of injuries",
     main="Model only with transitory effect (series with trend + effect)")
lines(staSmo$alphahat[,1]+staSmo3$alphahat[,14]*Z[1,14,], col="blue", lwd=2)

# model with transitory and permanent (stp) components
model2 <- SSModel(inj~0+stp+SSMcustom(Z,T,R,Q,a1,P1,P1inf,1,n), H=NA)

# function that assigns parameters to matrix elements
update2 <- function(pars, model, ...)
{
  model$Q[1,1,1]   <- exp(pars[1]) # eta variance
  model$Q[2,2,1]   <- exp(pars[2]) # zeta variance
  model$Q[3,3,1]   <- exp(pars[3]) # omega variance
  model$H[1,1,1]   <- exp(pars[4]) # epsilon variance
  model$T[15,15,31:156] <- logit(pars[5]) # delta parameter
  model
}

# estimate
fit2 <- fitSSM(model2, c(5,5,5,5,1), update2)

# state smoothing
staSmo2 <- KFS(fit2$model, smoothing="state")

plot(staSmo2$alphahat[,15]*fit2$model$Z[1,15,],
     ylab="Impact of the score system (n. of injuries)",
     main="Transitory component")
abline(v=2003+6/12, lty=2)

plot(staSmo2$alphahat[,1]*stp+staSmo2$alphahat[,15]*fit2$model$Z[1,15,],
     ylab="Impact of the score system (n. of injuries)",
     main="Permanent component + transitory component")
abline(v=2003+6/12, lty=2)

plot(inj, main="Injuries with level + intervention")
lines(staSmo2$alphahat[,1]*stp+
      staSmo2$alphahat[,15]*fit2$model$Z[1,15,]+
      staSmo2$alphahat[,2],
      col="blue", lwd=2)

# SIGNIFICANCE TESTS
# - permanent component
cat("\nPermanent level shift: ",staSmo4$alphahat[1,1])
cat("\nt-stat: ", staSmo4$alphahat[1,1]/sqrt(staSmo4$V[1,1,1]))
# - transitory component
cat("\nTransitory level shift (at time 0): ", staSmo4$alphahat[1,15])
cat("\nt-stat: ", staSmo4$alphahat[1,15]/sqrt(staSmo4$V[15,15,1]))
# - delta coefficient
cat("\ndelta =", logit(fit4$optim$par[5]))
