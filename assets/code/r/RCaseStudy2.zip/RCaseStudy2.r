# Case Study 2, Section 9.2 of
# Pelagatti (2015) Time Series Modelling with Unobserved Components. Chapman & Hall/CRC Press

# The aim is building a monthly real GDP measure for US exploiting the high correlation
# with the industrial production index.

library(KFAS)

# load data
data <- read.csv("GDP_IP_US.csv", stringsAsFactors = F)[,-1]
data$DATE <- as.Date(data$DATE, format="%d/%m/%Y")

# make system matrices
T <- matrix(0.0, 16, 16) # transition matrix container
T[1:2,1:2] <- T[1:2,3:4] <- T[3:4,3:4] <- diag(2)
T[11,2] <- T[12,11] <- T[13,6] <- T[14,13] <- T[15,10] <- T[16,15] <- 1

Q <- matrix(0.0, 8, 8)   # state disturbance covariance matrix
R <- matrix(0.0, 16, 8)  # matrix that assigns disturbances to state variables
R[3:10,] <- diag(8)

Z <- matrix(0.0, 2, 16)  # observation matrix
Z[,1:2] <- Z[,5:6] <- Z[,9:10] <- diag(2)
Z[2,11:16] <- 1

a1 <- matrix(0.0, 16, 1)     # initial state mean vector
P1 <- matrix(0.0, 16, 16)    # initial state covariance matrix
P1inf <- matrix(0.0, 16, 16) # initial state matrix: indicates diffuse state with ones on diagonal
P1inf[1:4,1:4] <- diag(4)
P1inf[11:12,11:12] <- diag(2)

# define state space object
model <- SSModel(cbind(INDPRO,GDP)~0+SSMcustom(Z,T,R,Q,a1,P1,P1inf,n=ncol(data)),
                 data=data, H=matrix(0,2,2))

# auxiliary functions
logit <- function(x) log(x/(1-x))     # logit function
sigmoid <- function(x) 1/(1+exp(-x))  # and its inverse

# function that maps the parameters into the system matrices
# [0] logit(rho), [1] logit(lambda/pi), [2:4] vech of chol of CovZeta, [5:7] vech of chol of CovKappa, [8:10] vech of chol of CovEps
update <- function(pars, model, ...)
{
  dRho <- sigmoid(pars[1])
  dLambda <- sigmoid(pars[2])*pi
  dCos <- dRho*cos(dLambda)
  dSin <- dRho*sin(dLambda)
  # T matrix
  model$T[5,5,1] <- model$T[6,6,1] <- model$T[7,7,1] <- model$T[8,8,1] <- dCos
  model$T[5,7,1] <- model$T[6,8,1] <- dSin
  model$T[7,5,1] <- model$T[8,6,1] <- -dSin
  
  # cov matrix Q
  mCholZeta  <- matrix(c(pars[3:4],0,pars[5]),2,2)
  mCholPsi   <- matrix(c(pars[6:7],0,pars[8]),2,2)
  mCholEps   <- matrix(c(pars[9:10],0,pars[11]),2,2)
  mVarCycle <- mCholPsi%*%t(mCholPsi)
  model$Q[1:2,1:2,1] <- mCholZeta%*%t(mCholZeta)
  model$Q[3:4,3:4,1] <- mVarCycle*(1-dRho);
  model$Q[5:6,5:6,1] <- mVarCycle*(1-dRho);
  model$Q[7:8,7:8,1] <- mCholEps%*%t(mCholEps);
  
  # cov matrix P1
  dRho1 <- dRho*cos(dLambda)
  dRho2 <- dRho*dRho*cos(2*dLambda)
  model$P1[5:6,5:6] <- mVarCycle	 # marginal covariance matrix of cycles
  model$P1[7:8,7:8] <- mVarCycle	 # marginal covariance matrix of cycles
  model$P1[13,6] <- model$P1[6,13] <- model$P1[14,13] <- model$P1[13,14] <- dRho1*mVarCycle[2,2]
  model$P1[14,6] <- model$P1[6,14] <- dRho2*mVarCycle[2,2]
  model$P1[13,5] <- model$P1[5,13] <- dRho1*mVarCycle[1,2]
  model$P1[14,5] <- model$P1[5,14] <- dRho2*mVarCycle[1,2]
  model$P1[15:16,15:16] <- model$Q[7:8,7:8,1]
  
  model
}

# starting values
rho        <- 0.9
lambda     <- 0.11
VarZetaGDP <- 3
VarPsiGDP  <- 2800
VarEpsGDP  <- 500
VarZetaIPI <- 0.003
VarPsiIPI  <- 0.11/(1-rho)
VarEpsIPI  <- 0.007
Corr = matrix(c(1,0.5,0.5,1),2,2) # initial correlation matrix among components
CovZeta <- diag(sqrt(c(VarZetaIPI,VarZetaGDP)))%*%Corr%*%diag(sqrt(c(VarZetaIPI,VarZetaGDP)))
CovPsi  <- diag(sqrt(c(VarPsiIPI,VarPsiGDP)))%*%Corr%*%diag(sqrt(c(VarPsiIPI,VarPsiGDP)))
CovEps  <- diag(sqrt(c(VarEpsIPI,VarEpsGDP)))%*%Corr%*%diag(sqrt(c(VarEpsIPI,VarEpsGDP)))
ChZeta  <- chol(CovZeta)[c(1,3,4)]
ChPsi   <- chol(CovPsi)[c(1,3,4)]
ChEps   <- chol(CovEps)[c(1,3,4)]

init <- c(logit(rho),logit(lambda/pi),ChZeta,ChPsi,ChEps)

# estimate model
fit <- fitSSM(model=model, inits=init, updatefn=update, method="BFGS")
pars <- fit$optim.out$par

# some output about the estimated parameters
if (fit$optim.out$convergence) cat("\n",fit$optim.out$message) else cat("\nStrong convergence")
cat("\nCycle Parameters")
cat("\nrho =", sigmoid(pars[1]))
cat("\nlambda =", sigmoid(pars[2])*pi)
cat("\nperiod =", 2/sigmoid(pars[2]))

cat("\nCov(Zeta) =")
print(fit$model$Q[1:2, 1:2, 1])

cat("\nCor(Zeta) =")
print(cov2cor(fit$model$Q[1:2, 1:2, 1]))

cat("\nCov(Kappa) =")
print(fit$model$Q[3:4, 3:4, 1])

cat("\nCor(Kappa) =")
print(cov2cor(fit$model$Q[3:4, 3:4, 1]))

cat("\nCov(Epsilon) =")
print(fit$model$Q[7:8, 7:8, 1])

cat("\nCor(Epsilon) =")
print(cov2cor(fit$model$Q[7:8, 7:8, 1]))

# state smoothing
smo <- KFS(fit$model, smoothing = "state")

mgdp <- ts(smo$alphahat[,2]+smo$alphahat[,6], start=c(1947,1), freq=12)
plot(mgdp, ylab="Mln of dollars", main="Monthly US real GDP (trend+cycle) and NBER contractions")
ylim <- par("usr")
polygon(x=c(1948+10/12,1948+10/12,1949+9/12,1949+9/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1953+6/12,1953+6/12,1954+4/12,1954+4/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1957+7/12,1957+7/12,1958+3/12,1958+3/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1960+3/12,1960+3/12,1961+1/12,1961+1/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1969+11/12,1969+11/12,1970,1970),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1970,1970,1970+10/12,1970+10/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1973+10/12,1973+10/12,1975+2/12,1975+2/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1980,1980,1980+6/12,1980+6/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1981+6/12,1981+6/12,1982+11/12,1982+11/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(1990+6/12,1990+6/12,1991+2/12,1991+2/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(2001+2/12,2001+2/12,2001+10/12,2001+10/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
polygon(x=c(2007+11/12,2007+11/12,2009+5/12,2009+5/12),y=ylim[c(3,4,4,3)]-5,col="gray80",border=NA)
lines(mgdptc)

# comparison with Conference Board CEI
cbdata <- read.csv("confboardbci.csv");
cei <- ts(cbdata$CEI, start=c(1959,1), freq=12)
mgdp59 <- window(mgdp,start=c(1959,1))
plot(mgdp59/mgdp59[1]*100, ylab="Index with base Jan-1959",
     main="Monthly GDP vs. Conference Board CEI")
lines(cei/cei[1]*100)
text(1983,350,"Monthly GDP",pos=4)
text(1983,180,"Conference Board CEI",pos=4)
