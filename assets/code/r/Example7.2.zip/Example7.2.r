library(KFAS)

dt <- read.csv("conferenceBoardBcIndex.csv", stringsAsFactors = FALSE)
y <- ts(dt[, -1], start = c(1960, 1), frequency = 12)
plot(y)


trend <- 1:nrow(y)

mod1 <- SSModel(y~trend+
                  SSMcycle(0.11, matrix(1:16, 4, 4)), 
                H = matrix(-2, 4, 4))
mod1$P1inf[9:16, 9:16] <- 0


# order of the pars: logit(rho), lambda, 10 pars with chol(SigmaKappa), 10 pars with chol(SigmaEps)
updt1 <- function(pars, model) {
  rho <- 1 / (1 + exp(-pars[1]))*0.999 # damping factor
  cs <- rho*cos(pars[2])
  sn <- rho*sin(pars[2])
  Ck <- matrix(c(pars[3], 0, 0, 0, pars[4:5], 0, 0, pars[6:8], 0, pars[9:12]), 4, 4)
  Ce <- matrix(c(pars[13], 0, 0, 0, pars[14:15], 0, 0, pars[16:18], 0, pars[19:22]), 4, 4)
  model$T[9, 9, 1] <- model$T[10, 10, 1] <- model$T[11, 11, 1] <- model$T[12, 12, 1] <-
    model$T[13, 13, 1] <- model$T[14, 14, 1] <- model$T[15, 15, 1] <- model$T[16, 16, 1] <- cs
  model$T[9, 10, 1] <- model$T[11, 12, 1] <- model$T[13, 14, 1] <- model$T[15, 16, 1] <- sn
  model$T[10, 9, 1] <- model$T[12, 11, 1] <- model$T[14, 13, 1] <- model$T[16, 15, 1] <- -sn
  model$Q[c(1, 3, 5, 7), c(1, 3, 5, 7), 1] <- model$Q[c(2, 4, 6, 8), c(2, 4, 6, 8), 1] <- t(Ck) %*% Ck
  model$P1[c(9, 11, 13, 15), c(9, 11, 13, 15)] <- model$P1[c(10, 12, 14, 16), c(10, 12, 14, 16)] <-
    model$Q[c(1, 3, 5, 7), c(1, 3, 5, 7), 1] / (1 - rho^2)
  model$H[, , 1] <- t(Ce) %*% Ce
  model
}

S <- var(y)
C <- chol(S)
init <- c(3.5, 0.1, C, chol(diag(diag(S))*0.1))

fit1 <- fitSSM(mod1, init, updt1)

# delete extreme additive outliers using auxiliary residuals
dsmo1 <- KFS(fit1$model)
ar <- rstandard(dsmo1, "pearson")
y[abs(ar) > 2.5] <- NA

mod2 <- SSModel(y~trend+
                  SSMcycle(0.11, matrix(1:16, 4, 4)), 
                H = matrix(-2, 4, 4))
mod2$P1inf[9:16, 9:16] <- 0

fit2 <- fitSSM(mod2, fit1$optim.out$par, updt1)


# covariance and correlation matrix of cycle disturbances
Sigma_k <- fit2$model$Q[c(1, 3, 5, 7), c(1, 3, 5, 7), 1]
Rho_k <- cov2cor(Sigma_k)

# eigenvalues of correlation matrix of kappa
eig <- eigen(Rho_k)
round(eig$values, 3)
round(eig$values/sum(eig$values), 3)

# model with rank one covariance matrix for kappa

# order of the pars: logit(rho), lambda, 4 pars for reduced rank SigmaEta, 10 pars with chol(SigmaEps)
updt2 <- function(pars, model) {
  rho <- 1 / (1 + exp(-pars[1]))*0.999 # damping factor
  cs <- rho*cos(pars[2])
  sn <- rho*sin(pars[2])
  Sk <- outer(pars[3:6], pars[3:6])
  Ce <- matrix(c(pars[7], 0, 0, 0, pars[8:9], 0, 0, pars[10:12], 0, pars[13:16]), 4, 4)
  model$T[9, 9, 1] <- model$T[10, 10, 1] <- model$T[11, 11, 1] <- model$T[12, 12, 1] <-
    model$T[13, 13, 1] <- model$T[14, 14, 1] <- model$T[15, 15, 1] <- model$T[16, 16, 1] <- cs
  model$T[9, 10, 1] <- model$T[11, 12, 1] <- model$T[13, 14, 1] <- model$T[15, 16, 1] <- sn
  model$T[10, 9, 1] <- model$T[12, 11, 1] <- model$T[14, 13, 1] <- model$T[16, 15, 1] <- -sn
  model$Q[c(1, 3, 5, 7), c(1, 3, 5, 7), 1] <- model$Q[c(2, 4, 6, 8), c(2, 4, 6, 8), 1] <- Sk
  model$P1[c(9, 11, 13, 15), c(9, 11, 13, 15)] <- model$P1[c(10, 12, 14, 16), c(10, 12, 14, 16)] <- Sk / (1 - rho^2)
  model$H[, , 1] <- t(Ce) %*% Ce
  model
}

eig2 <- eigen(Sigma_k)

init <- c(3.5, 0.1, sqrt(eig2$values[1])*eig2$vectors[, 1], fit2$optim.out$par[6:15])
fit3 <- fitSSM(mod2, init, updt2)

# smoothing of the four cycles, which are equal with different scales
smo3 <- KFS(fit3$model, smoothing = "state")$alphahat[, c(9, 11, 13, 15)]
plot(smo3, col = "blue", main = "Smoothed cycles (rank one)")

# common cycle
cc <- smo3[, 1]  # any cycle would do

# function to create shadings
shade <- function(x,start,end,col="gray")
{
  m <- 1/12
  sy <- start[1]
  sm <- start[2]-1
  ey <- end[1]
  em <- end[2]-1
  hilo <- range(x)
  polygon(x=c(sy+sm*m, sy+sm*m, ey+em*m, ey+em*m),
          y=c(hilo, rev(hilo)),
          density=NA, col=col, border=NA)
}

# plotting common cycle
plot(cc, main = "Common Cycle")
# NBER contraction shading
shade(cc, c(1960, 4), c(1961, 2))
shade(cc, c(1969,12), c(1970,11))
shade(cc, c(1973,11), c(1975, 3))
shade(cc, c(1980, 1), c(1980, 7))
shade(cc, c(1981, 7), c(1982,11))
shade(cc, c(1990, 7), c(1991, 3))
shade(cc, c(2001, 3), c(2001,11))
shade(cc, c(2007,12), c(2009, 6))
abline(h=0)
lines(cc, lwd=1, col = "blue")